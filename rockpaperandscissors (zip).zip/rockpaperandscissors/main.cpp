#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    char user, computer;
    int randNum;
    srand(time(0));
    randNum = rand() % 3;
    if (randNum == 0)
        computer = 'R'; //Rock
    else if (randNum == 1)
        computer = 'P'; //Paper
    else
      computer = 'S';  //Scissors
    cout << "Enter R, P, or S: ";
    cin >> user;

    //Determine the winner
    if(computer == 'R')
    {
        if (user == 'R')
            cout << "It's a tie!";
        else if(user == 'P')
            cout << "You Win! Paper covers rock";
            else
                cout << "You lose! Rock breaks scissors";
    }
    else if(computer == 'P')
        {
        if(user == 'R')
        cout << "You lose! Paper covers rock";
    else if(user == 'P')
        cout << "It's a tie!";
    else
        cout << "You Win! Scissors cut paper";
    }
    else
    {
        if (user == 'R')
            cout << "You Win! Rock breaks scissors";
    else if (user == 'P')
        cout << "You lose! Scissors cut paper";
    else
        cout << "It's a tie!";
    }

    return 0;
}
